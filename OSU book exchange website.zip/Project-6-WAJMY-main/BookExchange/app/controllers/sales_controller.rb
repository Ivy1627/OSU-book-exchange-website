
#Created on 07/24/2022 by Adam Hassen 

class SalesController < ApplicationController
  # Added by Jingxin Zhang 7/30/2022
  before_action :authenticate_user!, except: [:index, :show]
  before_action :correct_user, only:[:edit, :update, :destroy]
  
  def index
    @sales = Sale.all
  end

  def show
    @sale = Sale.find(params[:id])
  end

  def new
    @sale = Sale.new
  end

  def edit
    @sale = current_user.sales.find_by(id: params[:id])
  end

  def create
    @sale = current_user.sales.build(sale_params)
      if @sale.save
        redirect_to @sale
      else
        render :new, status: :unprocessable_entity 
      end
  end

  def update
    @sale = current_user.sales.find_by(id: params[:id])
      if @sale.update(sale_params)
        redirect_to @sale
      else
         render :edit, status: :unprocessable_entity 
    end
  end

  def destroy
    @sale = Sale.find(params[:id])
    @sale.destroy
    redirect_to sales_url, notice: "Sale was successfully destroyed"
  end

  # Added by Jingxin
  def correct_user
    @sale = current_user.sales.find_by(id: params[:id])
    redirect_to sales_path, notice: "you are not authorized to edit this listing" if @listing.nil?
  end

    def sale_params
      params.require(:sale).permit(:condition, :price, :email)
    end
end
