class ListingsController < ApplicationController

  # Added by Jingxin Zhang 7/30/2022
  before_action :authenticate_user!, except: [:index, :show]
  before_action :correct_user, only:[:edit, :update, :destroy]

  # Created 7/19/2022 by Matt Stuart
  def index
    @listings = Listing.all
    @recent_listings = Listing.all.order("created_at DESC").limit(20)
  end

  #created 7/30/2022 by Wenbo Mu
  def search
    @listings = Listing.where("title LIKE ?", "%"+params[:q]+"%") + Listing.where("category LIKE ?", "%"+params[:q]+"%")
  end

  def all
    @listings = Listing.all.order("title ASC")
  end

  # Created 7/19/2022 by Matt Stuart
  def show
    @listing = Listing.find(params[:id])
  end

  # Created 7/19/2022 by Matt Stuart
  # Edited by JIngxin Zhang 7/28/2022
  def new
    @listing = current_user.listings.build
  end

  # Created 7/20/2022 by Matt Stuart
  # Edited by JIngxin Zhang 7/28/2022
  def create
    @listing = current_user.listings.build(listing_params)

    if @listing.save
      redirect_to @listing
    else
      render :new, status: :unprocessable_entity
    end
  end

  # Created 7/20/2022 by Matt Stuart
  def edit
    @listing = Listing.find(params[:id])
  end

  # Created 7/20/2022 by Matt Stuart
  def update
    @listing = Listing.find(params[:id])

    if @listing.update(listing_params)
      redirect_to @listing
    else
      render :edit, status: :unprocessable_entity
    end
  end

  # Created 7/20/2022 by Matt Stuart
  def destroy
    @listing = Listing.find(params[:id])
    @listing.destroy

    redirect_to root_path, status: :see_other
  end

  # Created 7/28/2022 by Jingxin Zhang
  def correct_user
    @listing = current_user.listings.find_by(id: params[:id])
    redirect_to listing_path, notice: "you are not authorized to edit this listing" if @listing.nil?
  end

    private
      def listing_params
        params.require(:listing).permit(:title, :author, :description, :condition, :publisher, :language, :price, :avatar, :user_id, :email, :seller, :category)
      end
end
