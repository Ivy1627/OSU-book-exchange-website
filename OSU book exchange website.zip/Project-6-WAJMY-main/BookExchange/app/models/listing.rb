class Listing < ApplicationRecord
  has_many :users
  has_many :sales
  has_one_attached :avatar
end
