# Project-6-WAJMY

The workload among teammembers is distributed.

Matt wrote how to create, edit and destroy the listings and add image. He also come up with the scroll bar of the listing.
Wenbo installed devise and only allow users to create a listing when they are signed in. He also implemented the search bar.
Jingxin add seller and email info by hidden fields and relate users and listings and edited controller functions and views to allow only the user that created a listing to touch that listing.
Adam wrote the all the other available sellers for a certain book.

Install dependencies:
Cd to the BookExchange file
type bundle install to install all the gems in gem files;
type rake db:migrate to run pending migrations.
finally run rails s and open up "localhost:3000/" in the browser to see the homepage.

Structure of code:
We have three main scaffolds, which are listings, users and sales, and their models are associated.

How to use this website:
This website serves as a book exchange platform for osu students.
In order to fully use the website, you must register using an osu email and a password with at least 6 characters. 
From there, you can explore the books listed in our original database. There are 7 users and 25 books listed on the website.
The homepage lists all the books in an alphabetical order in a rolling bar. You can also search for a book by category or by name.
Our original books go up to the letter M, and there are many books under letter H.
You can add any new listing for a book and it will be updated onto the all the listings (recent, all and alphebetical bar)
Guests can view all the listings on the website but only signed in users can create a new listing. 
You can create a new listing by pressing the create a new listing button, and the website will ask you to input all the details of your book, 
and your contact info and name will be saved automatically as your email and username for your listings. You can change them in the “my account” page. 
You can edit or remove your own listing, but you will not be able edit/remove listings created by others. 
You can view all sellers in the “all sellers” link for other users of the same book. You can also click on “I have a better price!” 
under a book and simply input the price and condition of your book without creating a new listing from scratch.
As listings, you can't edit or delete other peoples sales unless it was the listing you created.
