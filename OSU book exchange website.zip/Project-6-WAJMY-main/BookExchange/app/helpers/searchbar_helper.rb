module SearchbarHelper
end
