Rails.application.routes.draw do
  devise_for :users, :controller => {
    :registrations => "users/registrations",
    :session => "users/sessions",
    :passwords => "users/passwords",
    :confirmations => "users/confirmations"}
  devise_scope :users do
    get 'sign_up', to: 'users/registration#new'
    get 'sign_in', to: 'users/sessions#new'
    delete 'sign_out', to: 'users/sessions#destroy'
    get 'search', to: "listings#search"
    get 'searchByCategory', to: "listings#searchByCategory"
    #get '/users/sign_out' => 'devise/sessions#destroy'
  end

  resources :sales
  root "listings#index"

  # Created by Matt
  get '/listings/all', :to => 'listings#all'
  resources :listings

  # Created by Jingxin


  # Created by Wenbo. Edited by Jingixn, added ":to =>" for the routes to work properly


  #Edited by Adam Hassen on 07/20/2022, I just added the route for the sells page
  get '/sales/new', :to => 'sales#new'
 
  #Commented the list of sellers route out until I have it working
  #get '/sell/index', :to => 'sell#index'

  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
end
