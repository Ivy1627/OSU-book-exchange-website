class AddListingIdToSales < ActiveRecord::Migration[7.0]
  def change
    add_column :sales, :listing_id, :integer
    add_index :sales, :listing_id
  end
end
