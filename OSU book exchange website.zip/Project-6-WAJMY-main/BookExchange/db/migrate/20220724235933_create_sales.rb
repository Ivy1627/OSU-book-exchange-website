class CreateSales < ActiveRecord::Migration[7.0]
  def change
    create_table :sales do |t|
      t.string :book_title
      t.string :condition
      t.decimal :price
      t.timestamps
    end
  end
end
