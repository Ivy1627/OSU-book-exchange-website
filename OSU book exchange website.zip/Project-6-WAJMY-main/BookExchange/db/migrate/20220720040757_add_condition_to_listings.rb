class AddConditionToListings < ActiveRecord::Migration[7.0]
  def change
    add_column :listings, :condition, :string
  end
end
